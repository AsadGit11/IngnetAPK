import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_v2ray_client/flutter_v2ray_client.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/server_model.dart';
import '../models/theme_model.dart';
import 'package:http/http.dart' as http;

const _serversCacheKey = 'ingnet_servers_cache';
const _themeKey = 'ingnet_theme';
const _activeServerKey = 'ingnet_active_server';
const _timeoutKey = 'ingnet_timeout_ms';
const _suppressRuWarningKey = 'ingnet_suppress_russia_warning';
const _notificationModeKey = 'ingnet_notification_mode';

enum AutoDepth { firstGood, halfList, fullList }

enum NotificationMode {
  speedOnly,
  buttonOnly,
  all,
  hidden,
}

class VpnState {
  final bool isConnected;
  final bool isConnecting;
  final String? activeName;
  final int rxBytes;
  final int txBytes;
  final Duration duration;
  final List<IngnetServer> servers;
  final bool loadingServers;
  final int timeoutMs;
  final bool suppressRuWarning;
  final String themeId;
  final NotificationMode notificationMode;

  VpnState({
    required this.isConnected,
    required this.isConnecting,
    required this.activeName,
    required this.rxBytes,
    required this.txBytes,
    required this.duration,
    required this.servers,
    required this.loadingServers,
    required this.timeoutMs,
    required this.suppressRuWarning,
    required this.themeId,
    required this.notificationMode,
  });

  VpnState copyWith({
    bool? isConnected,
    bool? isConnecting,
    String? activeName,
    int? rxBytes,
    int? txBytes,
    Duration? duration,
    List<IngnetServer>? servers,
    bool? loadingServers,
    int? timeoutMs,
    bool? suppressRuWarning,
    String? themeId,
    NotificationMode? notificationMode,
  }) {
    return VpnState(
      isConnected: isConnected ?? this.isConnected,
      isConnecting: isConnecting ?? this.isConnecting,
      activeName: activeName ?? this.activeName,
      rxBytes: rxBytes ?? this.rxBytes,
      txBytes: txBytes ?? this.txBytes,
      duration: duration ?? this.duration,
      servers: servers ?? this.servers,
      loadingServers: loadingServers ?? this.loadingServers,
      timeoutMs: timeoutMs ?? this.timeoutMs,
      suppressRuWarning: suppressRuWarning ?? this.suppressRuWarning,
      themeId: themeId ?? this.themeId,
      notificationMode: notificationMode ?? this.notificationMode,
    );
  }

  factory VpnState.initial() => VpnState(
        isConnected: false,
        isConnecting: false,
        activeName: null,
        rxBytes: 0,
        txBytes: 0,
        duration: Duration.zero,
        servers: const [],
        loadingServers: false,
        timeoutMs: 5000,
        suppressRuWarning: false,
        themeId: ingnetThemes.first.id,
        notificationMode: NotificationMode.all,
      );
}

final vpnProvider =
    StateNotifierProvider<VpnController, VpnState>((ref) => VpnController());

class VpnController extends StateNotifier<VpnState> {
  VpnController() : super(VpnState.initial()) {
    _init();
  }

  final FlutterV2ray _v2ray = FlutterV2ray();
  StreamSubscription<V2RayStatus>? _statusSub;

  SharedPreferences? _prefs;

  Future<void> _init() async {
    _prefs = await SharedPreferences.getInstance();

    await _v2ray.initialize(
      notificationIconResourceType: "mipmap",
      notificationIconResourceName: "ic_launcher",
    );

    final themeId = _prefs!.getString(_themeKey) ?? state.themeId;
    final timeoutMs = _prefs!.getInt(_timeoutKey) ?? state.timeoutMs;
    final suppressWarning =
        _prefs!.getBool(_suppressRuWarningKey) ?? state.suppressRuWarning;
    final notifModeIndex =
        _prefs!.getInt(_notificationModeKey) ?? NotificationMode.all.index;
    final notifMode = NotificationMode.values[notifModeIndex];

    List<IngnetServer> servers = [];
    final cached = _prefs!.getString(_serversCacheKey);
    if (cached != null) {
      servers = IngnetServer.decodeList(cached);
    }

    state = state.copyWith(
      themeId: themeId,
      timeoutMs: timeoutMs,
      suppressRuWarning: suppressWarning,
      servers: servers,
      notificationMode: notifMode,
    );

    _statusSub = _v2ray.onStatusChanged().listen((status) {
      state = state.copyWith(
        isConnected: status.state == V2RayState.connected,
        isConnecting: status.state == V2RayState.connecting,
        rxBytes: status.rxBytes,
        txBytes: status.txBytes,
        duration: Duration(seconds: status.duration),
      );
    });

    if (servers.isEmpty) {
      await refreshServers();
    }
  }

  @override
  void dispose() {
    _statusSub?.cancel();
    super.dispose();
  }

  IngnetTheme get currentTheme =>
      ingnetThemes.firstWhere((t) => t.id == state.themeId,
          orElse: () => ingnetThemes.first);

  Future<void> setTheme(String id) async {
    state = state.copyWith(themeId: id);
    await _prefs?.setString(_themeKey, id);
  }

  Future<void> setNotificationMode(NotificationMode mode) async {
    state = state.copyWith(notificationMode: mode);
    await _prefs?.setInt(_notificationModeKey, mode.index);
  }

  Future<void> setTimeoutMs(int value) async {
    state = state.copyWith(timeoutMs: value);
    await _prefs?.setInt(_timeoutKey, value);
  }

  Future<void> setSuppressRuWarning(bool value) async {
    state = state.copyWith(suppressRuWarning: value);
    await _prefs?.setBool(_suppressRuWarningKey, value);
  }

  Future<void> refreshServers() async {
    state = state.copyWith(loadingServers: true);
    List<IngnetServer> servers = [];

    try {
      final uri = Uri.parse(
          'https://raw.githubusercontent.com/INGNET06/INGNET/refs/heads/main/INGNETVPN.txt');
      final resp = await http.get(uri);
      if (resp.statusCode == 200) {
        final lines = resp.body.split('
');
        for (final line in lines) {
          final trimmed = line.trim();
          if (trimmed.isEmpty) continue;
          try {
            servers.add(IngnetServer.fromLine(trimmed));
          } catch (_) {}
        }
      }
    } catch (_) {
      // ignore, fallback below
    }

    if (servers.isEmpty) {
      servers = [
        IngnetServer(
          name: 'AUTO_SERVER',
          config: 'AUTO_SERVER',
        ),
        IngnetServer(
          name: 'NL-Turbo #1',
          config: 'NL-Turbo #1',
        ),
        IngnetServer(
          name: 'NL-Premium #2',
          config: 'NL-Premium #2',
        ),
        IngnetServer(
          name: 'DE-Secure #1',
          config: 'DE-Secure #1',
        ),
        IngnetServer(
          name: 'UK-Fast #1',
          config: 'UK-Fast #1',
        ),
      ];
    }

    state = state.copyWith(servers: servers, loadingServers: false);
    await _prefs?.setString(_serversCacheKey, IngnetServer.encodeList(servers));

    await testAllServersAndSort();
  }

  Future<void> testAllServersAndSort() async {
    final servers = [...state.servers];
    for (final s in servers) {
      try {
        final delay = await _v2ray.getServerDelay(
          config: s.config,
          timeout: state.timeoutMs,
        );
        s.delayMs = delay;
      } catch (_) {
        s.delayMs = 9999;
      }
    }
    servers.sort((a, b) => (a.delayMs ?? 9999).compareTo(b.delayMs ?? 9999));
    state = state.copyWith(servers: servers);
    await _prefs?.setString(_serversCacheKey, IngnetServer.encodeList(servers));
  }

  Future<void> testServer(IngnetServer server) async {
    try {
      final delay = await _v2ray.getServerDelay(
        config: server.config,
        timeout: state.timeoutMs,
      );
      server.delayMs = delay;
    } catch (_) {
      server.delayMs = 9999;
    }
    final servers = [...state.servers];
    servers.sort((a, b) => (a.delayMs ?? 9999).compareTo(b.delayMs ?? 9999));
    state = state.copyWith(servers: servers);
    await _prefs?.setString(_serversCacheKey, IngnetServer.encodeList(servers));
  }

  Future<void> connect(IngnetServer server) async {
    state = state.copyWith(isConnecting: true, activeName: server.name);

    await _v2ray.requestVpnPermission();

    await _v2ray.startV2Ray(
      remark: server.name,
      config: server.config,
      proxyOnly: false,
    );

    await _prefs?.setString(_activeServerKey, server.name);
  }

  Future<void> disconnect() async {
    await _v2ray.stopV2Ray();
    state = state.copyWith(
      isConnected: false,
      isConnecting: false,
      activeName: null,
      rxBytes: 0,
      txBytes: 0,
      duration: Duration.zero,
    );
  }

  void resetTraffic() {
    state = state.copyWith(rxBytes: 0, txBytes: 0);
  }
}