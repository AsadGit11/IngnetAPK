import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ProviderScope(child: IngnetApp()));
}

class IngnetApp extends StatelessWidget {
  const IngnetApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'INGNET VPN',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const HomeScreen(),
    );
  }
}