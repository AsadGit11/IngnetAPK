import 'dart:convert';

class IngnetServer {
  final String name;
  final String config;
  int? delayMs;

  IngnetServer({
    required this.name,
    required this.config,
    this.delayMs,
  });

  factory IngnetServer.fromLine(String line) {
    final trimmed = line.trim();
    if (trimmed.isEmpty) {
      throw ArgumentError('Empty server line');
    }

    String name = 'UNKNOWN';
    String config = trimmed;

    final hashIndex = trimmed.lastIndexOf('#');
    if (hashIndex != -1 && hashIndex < trimmed.length - 1) {
      final rawName = trimmed.substring(hashIndex + 1);
      name = Uri.decodeComponent(rawName);
    }

    return IngnetServer(
      name: name,
      config: config,
    );
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'config': config,
        'delayMs': delayMs,
      };

  factory IngnetServer.fromJson(Map<String, dynamic> json) => IngnetServer(
        name: json['name'] as String,
        config: json['config'] as String,
        delayMs: json['delayMs'] as int?,
      );

  static String encodeList(List<IngnetServer> list) =>
      jsonEncode(list.map((e) => e.toJson()).toList());

  static List<IngnetServer> decodeList(String source) {
    final data = jsonDecode(source) as List<dynamic>;
    return data
        .map((e) => IngnetServer.fromJson(e as Map<String, dynamic>))
        .toList();
  }
}