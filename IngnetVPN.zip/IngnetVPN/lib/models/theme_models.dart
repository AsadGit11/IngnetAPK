import 'package:flutter/material.dart';

class IngnetTheme {
  final String id;
  final String name;
  final Color primary;
  final Color background;
  final Color accent;
  final Color pingGood;
  final Color pingMedium;
  final Color pingBad;
  final TextStyle titleStyle;
  final TextStyle subtitleStyle;
  final Alignment connectAlignment;
  final bool showScanlines;
  final Gradient? backgroundGradient;

  const IngnetTheme({
    required this.id,
    required this.name,
    required this.primary,
    required this.background,
    required this.accent,
    required this.pingGood,
    required this.pingMedium,
    required this.pingBad,
    required this.titleStyle,
    required this.subtitleStyle,
    required this.connectAlignment,
    this.showScanlines = false,
    this.backgroundGradient,
  });
}

/// 10 тем (Adrenalin, Graffiti, Classic, Monochrome, Cyberpunk, Matrix,
/// Fire, Ocean, Gold, Dark Neon) – стилистика максимально различается.
final List<IngnetTheme> ingnetThemes = [
  IngnetTheme(
    id: 'adrenalin',
    name: 'Adrenalin',
    primary: const Color(0xFF00FF41),
    background: Colors.black,
    accent: const Color(0xFF00FF41),
    pingGood: Colors.greenAccent,
    pingMedium: Colors.orangeAccent,
    pingBad: Colors.redAccent,
    titleStyle: const TextStyle(
      color: Color(0xFF00FF41),
      fontSize: 26,
      fontWeight: FontWeight.bold,
      letterSpacing: 2,
    ),
    subtitleStyle: const TextStyle(
      color: Colors.white70,
      fontSize: 14,
    ),
    connectAlignment: Alignment.center,
    showScanlines: true,
    backgroundGradient: const LinearGradient(
      colors: [Colors.black, Color(0xFF001100)],
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
    ),
  ),
  IngnetTheme(
    id: 'graffiti',
    name: 'Graffiti',
    primary: const Color(0xFFFF0080),
    background: const Color(0xFF1E1E2C),
    accent: const Color(0xFFFFD700),
    pingGood: Colors.lightGreenAccent,
    pingMedium: Colors.yellowAccent,
    pingBad: Colors.redAccent,
    titleStyle: const TextStyle(
      color: Colors.white,
      fontSize: 24,
      fontWeight: FontWeight.w900,
      letterSpacing: 1.5,
    ),
    subtitleStyle: const TextStyle(
      color: Colors.white70,
      fontSize: 13,
    ),
    connectAlignment: Alignment.topCenter,
    showScanlines: false,
    backgroundGradient: const LinearGradient(
      colors: [Color(0xFF1E1E2C), Color(0xFF3A1C71)],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    ),
  ),
  IngnetTheme(
    id: 'classic',
    name: 'Classic',
    primary: const Color(0xFF2196F3),
    background: Colors.white,
    accent: const Color(0xFF1565C0),
    pingGood: Colors.green,
    pingMedium: Colors.orange,
    pingBad: Colors.red,
    titleStyle: const TextStyle(
      color: Colors.black87,
      fontSize: 22,
      fontWeight: FontWeight.bold,
    ),
    subtitleStyle: const TextStyle(
      color: Colors.black54,
      fontSize: 13,
    ),
    connectAlignment: Alignment.centerRight,
    showScanlines: false,
    backgroundGradient: null,
  ),
  IngnetTheme(
    id: 'monochrome',
    name: 'Monochrome',
    primary: Colors.white,
    background: Colors.black,
    accent: Colors.grey,
    pingGood: Colors.white,
    pingMedium: Colors.white70,
    pingBad: Colors.white54,
    titleStyle: const TextStyle(
      color: Colors.white,
      fontSize: 24,
      fontWeight: FontWeight.bold,
    ),
    subtitleStyle: const TextStyle(
      color: Colors.white70,
      fontSize: 13,
    ),
    connectAlignment: Alignment.center,
    showScanlines: true,
    backgroundGradient: const LinearGradient(
      colors: [Colors.black, Colors.grey],
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
    ),
  ),
  IngnetTheme(
    id: 'cyberpunk',
    name: 'Cyberpunk',
    primary: const Color(0xFFFF00FF),
    background: const Color(0xFF050014),
    accent: const Color(0xFF00FFFF),
    pingGood: Colors.limeAccent,
    pingMedium: Colors.amberAccent,
    pingBad: Colors.redAccent,
    titleStyle: const TextStyle(
      color: Colors.white,
      fontSize: 26,
      fontWeight: FontWeight.bold,
    ),
    subtitleStyle: const TextStyle(
      color: Colors.white70,
      fontSize: 13,
    ),
    connectAlignment: Alignment.bottomCenter,
    showScanlines: true,
    backgroundGradient: const LinearGradient(
      colors: [Color(0xFF050014), Color(0xFF33004B)],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    ),
  ),
  IngnetTheme(
    id: 'matrix',
    name: 'Matrix',
    primary: const Color(0xFF00FF00),
    background: Colors.black,
    accent: const Color(0xFF00CC00),
    pingGood: Colors.greenAccent,
    pingMedium: Colors.yellowAccent,
    pingBad: Colors.redAccent,
    titleStyle: const TextStyle(
      color: Color(0xFF00FF00),
      fontSize: 24,
      fontWeight: FontWeight.bold,
      letterSpacing: 3,
    ),
    subtitleStyle: const TextStyle(
      color: Colors.greenAccent,
      fontSize: 12,
    ),
    connectAlignment: Alignment.centerLeft,
    showScanlines: true,
    backgroundGradient: null,
  ),
  IngnetTheme(
    id: 'fire',
    name: 'Fire',
    primary: const Color(0xFFFF4500),
    background: const Color(0xFF260000),
    accent: const Color(0xFFFFA500),
    pingGood: Colors.lightGreenAccent,
    pingMedium: Colors.yellowAccent,
    pingBad: Colors.redAccent,
    titleStyle: const TextStyle(
      color: Colors.white,
      fontSize: 24,
      fontWeight: FontWeight.bold,
    ),
    subtitleStyle: const TextStyle(
      color: Colors.white70,
      fontSize: 13,
    ),
    connectAlignment: Alignment.topRight,
    showScanlines: false,
    backgroundGradient: const LinearGradient(
      colors: [Color(0xFF260000), Color(0xFF660000)],
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
    ),
  ),
  IngnetTheme(
    id: 'ocean',
    name: 'Ocean',
    primary: const Color(0xFF00BFFF),
    background: const Color(0xFF001F3F),
    accent: const Color(0xFF00FFFF),
    pingGood: Colors.lightGreenAccent,
    pingMedium: Colors.yellowAccent,
    pingBad: Colors.redAccent,
    titleStyle: const TextStyle(
      color: Colors.white,
      fontSize: 24,
      fontWeight: FontWeight.bold,
    ),
    subtitleStyle: const TextStyle(
      color: Colors.white70,
      fontSize: 13,
    ),
    connectAlignment: Alignment.center,
    showScanlines: false,
    backgroundGradient: const LinearGradient(
      colors: [Color(0xFF001F3F), Color(0xFF0074D9)],
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
    ),
  ),
  IngnetTheme(
    id: 'gold',
    name: 'Gold',
    primary: const Color(0xFFFFD700),
    background: const Color(0xFF2B2113),
    accent: const Color(0xFFFFA000),
    pingGood: Colors.lightGreenAccent,
    pingMedium: Colors.yellowAccent,
    pingBad: Colors.redAccent,
    titleStyle: const TextStyle(
      color: Colors.white,
      fontSize: 24,
      fontWeight: FontWeight.bold,
    ),
    subtitleStyle: const TextStyle(
      color: Colors.white70,
      fontSize: 13,
    ),
    connectAlignment: Alignment.bottomRight,
    showScanlines: false,
    backgroundGradient: const LinearGradient(
      colors: [Color(0xFF2B2113), Color(0xFF8B6B2C)],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    ),
  ),
  IngnetTheme(
    id: 'dark_neon',
    name: 'Dark Neon',
    primary: const Color(0xFFFF1493),
    background: const Color(0xFF050505),
    accent: const Color(0xFF00FFFF),
    pingGood: Colors.lightGreenAccent,
    pingMedium: Colors.yellowAccent,
    pingBad: Colors.redAccent,
    titleStyle: const TextStyle(
      color: Colors.white,
      fontSize: 24,
      fontWeight: FontWeight.bold,
    ),
    subtitleStyle: const TextStyle(
      color: Colors.white70,
      fontSize: 13,
    ),
    connectAlignment: Alignment.center,
    showScanlines: true,
    backgroundGradient: const LinearGradient(
      colors: [Color(0xFF050505), Color(0xFF101020)],
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
    ),
  ),
];