import 'package:flutter/material.dart';

class ScanlinesPainter extends CustomPainter {
  final Color color;
  final double spacing;
  final double opacity;

  ScanlinesPainter({
    this.color = Colors.white,
    this.spacing = 3,
    this.opacity = 0.06,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..strokeWidth = 1;

    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}