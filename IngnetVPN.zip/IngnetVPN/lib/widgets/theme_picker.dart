import 'package:flutter/material.dart';
import '../models/theme_model.dart';

class ThemePicker extends StatelessWidget {
  final String currentThemeId;
  final void Function(String) onSelect;

  const ThemePicker({
    super.key,
    required this.currentThemeId,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding:
          const EdgeInsets.only(top: 16, left: 16, right: 16, bottom: 24),
      child: GridView.builder(
        shrinkWrap: true,
        itemCount: ingnetThemes.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 2.4,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
        ),
        itemBuilder: (context, index) {
          final t = ingnetThemes[index];
          final selected = t.id == currentThemeId;
          return GestureDetector(
            onTap: () => onSelect(t.id),
            child: Container(
              decoration: BoxDecoration(
                gradient: t.backgroundGradient ??
                    LinearGradient(
                      colors: [t.primary, t.accent],
                    ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: selected ? Colors.white : Colors.black26,
                  width: selected ? 2 : 1,
                ),
              ),
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Icon(
                    Icons.color_lens,
                    color: Colors.white,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      t.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  if (selected)
                    const Icon(
                      Icons.check_circle,
                      color: Colors.white,
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}