import 'package:flutter/material.dart';
import '../models/server_model.dart';
import '../models/theme_model.dart';

class ServerList extends StatelessWidget {
  final List<IngnetServer> servers;
  final bool loading;
  final IngnetTheme theme;
  final void Function(IngnetServer) onSelect;
  final Future<void> Function() onTestAll;
  final void Function(IngnetServer) onTestOne;

  const ServerList({
    super.key,
    required this.servers,
    required this.loading,
    required this.theme,
    required this.onSelect,
    required this.onTestAll,
    required this.onTestOne,
  });

  Color _pingColor(int? delay) {
    if (delay == null) return Colors.grey;
    if (delay < 300) return theme.pingGood;
    if (delay < 700) return theme.pingMedium;
    return theme.pingBad;
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (servers.isEmpty) {
      return const Text('Нет доступных серверов');
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              'Серверы',
              style: theme.subtitleStyle.copyWith(fontWeight: FontWeight.bold),
            ),
            const Spacer(),
            TextButton(
              onPressed: onTestAll,
              child: const Text('Проверить все'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Expanded(
          child: ListView.builder(
            itemCount: servers.length,
            itemBuilder: (context, index) {
              final s = servers[index];
              final pingColor = _pingColor(s.delayMs);
              final delayText =
                  s.delayMs == null ? '—' : '${s.delayMs} ms';

              return Card(
                color: theme.background.withOpacity(0.7),
                child: ListTile(
                  onTap: () => onSelect(s),
                  title: Text(
                    s.name,
                    style: theme.subtitleStyle,
                  ),
                  subtitle: Text(
                    'PING: $delayText',
                    style: TextStyle(color: pingColor),
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.speed),
                    onPressed: () => onTestOne(s),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}