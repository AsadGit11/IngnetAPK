import 'package:flutter/material.dart';
import '../utils/format_bytes.dart';

class TrafficCounter extends StatelessWidget {
  final int rxBytes;
  final int txBytes;
  final VoidCallback onReset;
  final Color accent;

  const TrafficCounter({
    super.key,
    required this.rxBytes,
    required this.txBytes,
    required this.onReset,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Входящий: ${formatBytes(rxBytes)}',
              style: TextStyle(color: accent, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 4),
            Text(
              'Исходящий: ${formatBytes(txBytes)}',
              style: TextStyle(color: accent, fontWeight: FontWeight.w600),
            ),
          ],
        ),
        TextButton(
          onPressed: onReset,
          child: const Text('Сбросить'),
        ),
      ],
    );
  }
}