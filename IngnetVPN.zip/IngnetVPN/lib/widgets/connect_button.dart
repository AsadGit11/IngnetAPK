import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

class ConnectButton extends StatelessWidget {
  final bool isConnected;
  final bool isConnecting;
  final VoidCallback onPressed;
  final Color color;
  final Color background;

  const ConnectButton({
    super.key,
    required this.isConnected,
    required this.isConnecting,
    required this.onPressed,
    required this.color,
    required this.background,
  });

  String get _label {
    if (isConnecting) return 'ПОДКЛЮЧЕНИЕ...';
    if (isConnected) return 'VPN АКТИВЕН';
    return 'НАЖМИ ДЛЯ VPN';
  }

  @override
  Widget build(BuildContext context) {
    final base = SizedBox(
      width: 240,
      height: 240,
      child: Stack(
        alignment: Alignment.center,
        children: [
          _buildPulses(),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: isConnected ? color : background,
              foregroundColor: isConnected ? background : color,
              shape: const CircleBorder(),
              elevation: 8,
              padding: EdgeInsets.zero,
            ),
            onPressed: isConnecting ? null : onPressed,
            child: Center(
              child: Text(
                _label,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );

    if (isConnecting) {
      return base
          .animate(
            onPlay: (c) => c.repeat(),
          )
          .shimmer(duration: 1200.ms);
    }

    return base;
  }

  Widget _buildPulses() {
    final circle = Container(
      width: 240,
      height: 240,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: color.withOpacity(0.3), width: 2),
      ),
    );

    return Stack(
      alignment: Alignment.center,
      children: [
        circle
            .animate(
              onPlay: (c) => c.repeat(),
            )
            .scale(
              begin: const Offset(1, 1),
              end: const Offset(1.6, 1.6),
              duration: 1200.ms,
            )
            .fadeOut(duration: 1200.ms),
        circle
            .animate(
              delay: 600.ms,
              onPlay: (c) => c.repeat(),
            )
            .scale(
              begin: const Offset(1, 1),
              end: const Offset(1.6, 1.6),
              duration: 1200.ms,
            )
            .fadeOut(duration: 1200.ms),
      ],
    );
  }
}