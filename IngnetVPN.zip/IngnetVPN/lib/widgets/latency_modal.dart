import 'package:flutter/material.dart';
import '../models/server_model.dart';

class LatencyModal extends StatefulWidget {
  final IngnetServer server;
  final Future<int?> Function(String url) onTest;

  const LatencyModal({
    super.key,
    required this.server,
    required this.onTest,
  });

  @override
  State<LatencyModal> createState() => _LatencyModalState();
}

class _LatencyModalState extends State<LatencyModal> {
  String _selected = 'https://www.google.com';
  final _customController = TextEditingController();
  int? _result;
  bool _loading = false;

  Future<void> _run() async {
    setState(() {
      _loading = true;
      _result = null;
    });
    final url =
        _selected == 'custom' ? _customController.text.trim() : _selected;
    if (url.isEmpty) {
      setState(() => _loading = false);
      return;
    }
    final delay = await widget.onTest(url);
    setState(() {
      _result = delay;
      _loading = false;
    });
  }

  @override
  void dispose() {
    _customController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Padding(
        padding:
            const EdgeInsets.only(top: 16, left: 16, right: 16, bottom: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Тест задержки: ${widget.server.name}',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 12),
            DropdownButton<String>(
              value: _selected,
              isExpanded: true,
              items: const [
                DropdownMenuItem(
                  value: 'https://www.google.com',
                  child: Text('Google'),
                ),
                DropdownMenuItem(
                  value: 'https://www.youtube.com',
                  child: Text('YouTube'),
                ),
                DropdownMenuItem(
                  value: 'https://www.bbc.com',
                  child: Text('BBC'),
                ),
                DropdownMenuItem(
                  value: 'custom',
                  child: Text('Custom'),
                ),
              ],
              onChanged: (v) {
                if (v == null) return;
                setState(() => _selected = v);
              },
            ),
            if (_selected == 'custom') ...[
              const SizedBox(height: 8),
              TextField(
                controller: _customController,
                decoration: const InputDecoration(
                  labelText: 'Test URL',
                ),
              ),
            ],
            const SizedBox(height: 12),
            if (_loading)
              const CircularProgressIndicator()
            else
              ElevatedButton(
                onPressed: _run,
                child: const Text('Тест'),
              ),
            const SizedBox(height: 8),
            if (_result != null)
              Text(
                'Результат: ${_result} ms',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
          ],
        ),
      ),
    );
  }
}