import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class SidebarDrawer extends StatelessWidget {
  final VoidCallback onThemes;
  final VoidCallback onSettings;
  final VoidCallback onRefreshServers;

  const SidebarDrawer({
    super.key,
    required this.onThemes,
    required this.onSettings,
    required this.onRefreshServers,
  });

  Future<void> _openTelegram() async {
    final uri = Uri.parse('https://t.me/INGNET06');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            const ListTile(
              title: Text(
                '⚡ INGNET VPN',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.telegram),
              title: const Text('TG @INGNET06'),
              onTap: _openTelegram,
            ),
            ListTile(
              leading: const Icon(Icons.color_lens),
              title: const Text('Темы'),
              onTap: onThemes,
            ),
            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text('Настройки'),
              onTap: onSettings,
            ),
            ListTile(
              leading: const Icon(Icons.refresh),
              title: const Text('Обновить сервера'),
              onTap: onRefreshServers,
            ),
          ],
        ),
      ),
    );
  }
}