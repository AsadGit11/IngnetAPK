import 'package:flutter/material.dart';
import '../core/vpn_provider.dart';

class SettingsModal extends StatefulWidget {
  final int timeoutMs;
  final bool suppressRuWarning;
  final NotificationMode notificationMode;
  final void Function(int) onTimeoutChanged;
  final void Function(bool) onSuppressWarningChanged;
  final void Function(NotificationMode) onNotificationModeChanged;

  const SettingsModal({
    super.key,
    required this.timeoutMs,
    required this.suppressRuWarning,
    required this.notificationMode,
    required this.onTimeoutChanged,
    required this.onSuppressWarningChanged,
    required this.onNotificationModeChanged,
  });

  @override
  State<SettingsModal> createState() => _SettingsModalState();
}

class _SettingsModalState extends State<SettingsModal> {
  late TextEditingController _timeoutController;

  @override
  void initState() {
    super.initState();
    _timeoutController =
        TextEditingController(text: widget.timeoutMs.toString());
  }

  @override
  void dispose() {
    _timeoutController.dispose();
    super.dispose();
  }

  void _applyTimeout() {
    final value = int.tryParse(_timeoutController.text.trim());
    if (value != null && value > 0) {
      widget.onTimeoutChanged(value);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Padding(
        padding:
            const EdgeInsets.only(top: 16, left: 16, right: 16, bottom: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Настройки',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                const Expanded(child: Text('Таймаут (ms)')),
                SizedBox(
                  width: 100,
                  child: TextField(
                    controller: _timeoutController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      isDense: true,
                    ),
                    onSubmitted: (_) => _applyTimeout(),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Отключить предупреждение по РФ'),
              value: widget.suppressRuWarning,
              onChanged: widget.onSuppressWarningChanged,
            ),
            const SizedBox(height: 12),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Уведомление в шторке',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
            Column(
              children: [
                RadioListTile<NotificationMode>(
                  title: const Text('Только скорость'),
                  value: NotificationMode.speedOnly,
                  groupValue: widget.notificationMode,
                  onChanged: (v) {
                    if (v != null) widget.onNotificationModeChanged(v);
                  },
                ),
                RadioListTile<NotificationMode>(
                  title: const Text('Только кнопка'),
                  value: NotificationMode.buttonOnly,
                  groupValue: widget.notificationMode,
                  onChanged: (v) {
                    if (v != null) widget.onNotificationModeChanged(v);
                  },
                ),
                RadioListTile<NotificationMode>(
                  title: const Text('Скорость и кнопка'),
                  value: NotificationMode.all,
                  groupValue: widget.notificationMode,
                  onChanged: (v) {
                    if (v != null) widget.onNotificationModeChanged(v);
                  },
                ),
                RadioListTile<NotificationMode>(
                  title: const Text('Полностью скрыть'),
                  value: NotificationMode.hidden,
                  groupValue: widget.notificationMode,
                  onChanged: (v) {
                    if (v != null) widget.onNotificationModeChanged(v);
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}