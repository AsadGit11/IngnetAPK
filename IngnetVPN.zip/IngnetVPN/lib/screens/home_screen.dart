import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/vpn_provider.dart';
import '../models/theme_model.dart';
import '../widgets/connect_button.dart';
import '../widgets/traffic_counter.dart';
import '../widgets/server_list.dart';
import '../widgets/theme_picker.dart';
import '../widgets/settings_modal.dart';
import '../widgets/latency_modal.dart';
import '../widgets/sidebar_drawer.dart';
import '../utils/scanlines_painter.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  bool _firstDialogShown = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final state = ref.read(vpnProvider);
    if (!_firstDialogShown) {
      _firstDialogShown = true;
      if (!state.suppressRuWarning) {
        _showRussiaWarning();
      }
    }
  }

  Future<void> _showRussiaWarning() async {
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text(
          'ВНИМАНИЕ',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        content: const SingleChildScrollView(
          child: Text(
            'НАСТОЯТЕЛЬНО ПРОШУ НЕ ЗАПУСКАТЬ ДАННЫЕ АНТИЗАГЛУШКИ В РОССИЙСКИХ '
            'СЕРВИСАХ Т.К. УЖЕ ПРОВЕРЕНО ЧТО ЭТИ СЕРВИСЫ БЛОКИРУЮТ РАБОТУ И '
            'ПРИВОДЯТ К ПОЛНОЙ НЕРАБОТОСПОСОБНОСТИ. При наличии на телефоне '
            'российских приложений (VK, Сбер, Госуслуги и др.) — использовать '
            'с осторожностью.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Понял, продолжить'),
          ),
        ],
      ),
    );
  }

  Future<void> _showFirstConnectDialog() async {
    await showDialog(
      context: context,
      builder: (ctx) {
        final state = ref.read(vpnProvider);
        final theme = state.currentTheme;
        return AlertDialog(
          backgroundColor: theme.background,
          title: Text(
            'Ассаламу Аллейкум',
            style: theme.titleStyle,
          ),
          content: SingleChildScrollView(
            child: Text(
              'Ассаламу Аллейкум братья и сестры. Подписывайтесь на телеграм канал. '
              'Ваша поддержка поможет мне в продвижении данного проекта и даст '
              'больше мотивации для работы. Заранее благодарен всем.',
              style: theme.subtitleStyle,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('Отмена'),
            ),
            TextButton(
              onPressed: () async {
                Navigator.of(ctx).pop();
                final uri = Uri.parse('https://t.me/INGNET06');
                // ignore: use_build_context_synchronously
                // откроется в системном браузере
              },
              child: const Text('Открыть канал'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(vpnProvider);
    final controller = ref.read(vpnProvider.notifier);
    final theme = controller.currentTheme;

    final body = Stack(
      children: [
        if (theme.backgroundGradient != null ||
            theme.showScanlines) ...[
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: theme.backgroundGradient,
                color: theme.backgroundGradient == null
                    ? theme.background
                    : null,
              ),
            ),
          ),
          if (theme.showScanlines)
            Positioned.fill(
              child: CustomPaint(
                painter: ScanlinesPainter(color: theme.primary),
              ),
            ),
        ] else
          Container(color: theme.background),
        SafeArea(
          child: Column(
            children: [
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [
                    Text(
                      'INGNET VPN',
                      style: theme.titleStyle,
                    ),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.menu),
                      color: theme.primary,
                      onPressed: () =>
                          Scaffold.of(context).openDrawer(),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  children: [
                    Expanded(
                      child: Align(
                        alignment: theme.connectAlignment,
                        child: ConnectButton(
                          isConnected: state.isConnected,
                          isConnecting: state.isConnecting,
                          color: theme.primary,
                          background: theme.background,
                          onPressed: () async {
                            if (!state.isConnected) {
                              await _showFirstConnectDialog();
                              if (state.servers.isEmpty) {
                                await controller.refreshServers();
                              }
                              if (state.servers.isNotEmpty) {
                                await controller
                                    .connect(state.servers.first);
                              }
                            } else {
                              await controller.disconnect();
                            }
                          },
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      child: TrafficCounter(
                        rxBytes: state.rxBytes,
                        txBytes: state.txBytes,
                        accent: theme.accent,
                        onReset: controller.resetTraffic,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      child: Text(
                        '⚠️ НЕ ИСПОЛЬЗОВАТЬ В РОССИЙСКИХ СЕРВИСАХ',
                        style: const TextStyle(
                          color: Colors.red,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    if (theme.id != 'monochrome')
                      SizedBox(
                        height: 260,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: ServerList(
                            servers: state.servers,
                            loading: state.loadingServers,
                            theme: theme,
                            onSelect: (s) async {
                              await controller.connect(s);
                            },
                            onTestAll: () =>
                                controller.testAllServersAndSort(),
                            onTestOne: (s) => controller.testServer(s),
                          ),
                        ),
                      )
                    else
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                        child: Text(
                          'Monochrome режим: фокус на настройках.',
                          style: theme.subtitleStyle,
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );

    return Scaffold(
      drawer: SidebarDrawer(
        onThemes: () {
          Navigator.of(context).pop();
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            backgroundColor: Colors.black.withOpacity(0.9),
            builder: (_) => ThemePicker(
              currentThemeId: state.themeId,
              onSelect: (id) {
                controller.setTheme(id);
                Navigator.of(context).pop();
              },
            ),
          );
        },
        onSettings: () {
          Navigator.of(context).pop();
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            builder: (_) => SettingsModal(
              timeoutMs: state.timeoutMs,
              suppressRuWarning: state.suppressRuWarning,
              notificationMode: state.notificationMode,
              onTimeoutChanged: controller.setTimeoutMs,
              onSuppressWarningChanged: controller.setSuppressRuWarning,
              onNotificationModeChanged: controller.setNotificationMode,
            ),
          );
        },
        onRefreshServers: () async {
          Navigator.of(context).pop();
          await controller.refreshServers();
        },
      ),
      body: body,
    );
  }
}